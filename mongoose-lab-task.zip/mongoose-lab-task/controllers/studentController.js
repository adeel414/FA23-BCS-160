const Student = require("../models/student");

exports.createStudent = async () => {
    const newStudent = new Student({
        name: "Adeel",
        age: 19,
        course: "Software Engineering",
        isEnrolled: true
    });

    await newStudent.save();
    console.log("Student Added");
};
exports.getAllStudents = async () => {
    const studentList = await Student.find();
    console.log("All Students:");
    console.log(studentList);
};

exports.updateStudent = async () => {
    await Student.updateOne(
        { name: "Adeel" },
        { age: 19, course: "    Software Engineering" }
    );
    console.log("Student Updated");
};
exports.deleteStudent = async () => {
    await Student.deleteOne({ name: "Adeel" });
    console.log("Student Deleted");
};
exports.findByCourse = async () => {
    const enrolledStudents = await Student.find({ course: "Software Engineering" });
    console.log("Students in Software Engineering:");
    console.log(enrolledStudents);
};