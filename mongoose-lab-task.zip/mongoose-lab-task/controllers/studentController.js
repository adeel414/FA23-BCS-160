const Student = require("../models/student");

exports.createStudent = async () => {
    const student = new Student({
        name: "Adeel",
        age: 19,
        course: "Software Engineering",
        isEnrolled: true
    });

    await student.save();
    console.log("Student Added");
};
exports.getAllStudents = async () => {
    const students = await Student.find();
    console.log("All Students:");
    console.log(students);
};

exports.updateStudent = async () => {
    await Student.updateOne(
        { name: "Adeel" },
        { age: 19, course: "    Software Engineering" }
    );
    console.log("Student Updated");
};
exports.deleteStudent = async () => {
    await Student.deleteOne({ name: "Adeel" });
    console.log("Student Deleted");
};
exports.findByCourse = async () => {
    const students = await Student.find({ course: "Software Engineering" });
    console.log("Students in Software Engineering:");
    console.log(students);
};