// Activity#4

const mongoose = require('mongoose');

mongoose.connect('mongodb://127.0.0.1:27017/labDB')
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.log('Connection Error:', err));

const studentSchema = new mongoose.Schema({
  name: { 
    type: String, 
    required: true 
  },
  age: { 
    type: Number, 
    required: true, 
    min: 18, 
    max: 60 
  },
  grade: { 
    type: String, 
    required: true 
  }
});

const Student = mongoose.model('Student', studentSchema);

const newStudent = new Student({
  name: 'Zain',   
  age: 20,         
  grade: 'A'
});
newStudent.save()
  .then(() => console.log('Student saved!'))
  .catch(err => console.log('Validation Error:', err));

// Activity#5

const mongoose = require('mongoose');

mongoose.connect('mongodb://127.0.0.1:27017/labDB')
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.log('Connection Error:', err));


const courseSchema = new mongoose.Schema({
  name: String,
  duration: String
});

const Course = mongoose.model('Course', courseSchema);

const studentSchema = new mongoose.Schema({
  name: String,
  age: Number,
  grade: String,
  enrolledCourse: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Course' 
  }
});

const Student = mongoose.model('Student', studentSchema);

const newCourse = new Course({
  name: 'web tech',
  duration: '6 months'
});

newCourse.save()
  .then(course => {
    const newStudent = new Student({
      name: 'Zain',
      age: 20,
      grade: 'A',
      enrolledCourse: course._id
    });
    return newStudent.save();
  })
  .then(student => {
    console.log('Student saved:', student);

    
    return Student.findOne({ name: 'John Doe' })
      .populate('enrolledCourse');
  })
  .then(student => {
    console.log('Student with populated course:', student);
  })
  .catch(err => console.log('Error:', err));




const mongoose = require('mongoose')
mongoose.connect('mongodb://localhost:27017/uni')
.then(()=> console.log("Connect to Mongodb"))
.catch((err)=> console.error("cannot connect",err))

const studentSchema = new mongoose.Schema({
    name : String,
    age : Number,
    grade : String
});
const StudentModel = mongoose.model('student',studentSchema);
const newStudent = new StudentModel({
    name : "Zain",
    age : 90,
    grade : "B"
});
newStudent.save()
.then(() => console.log("Student Save"))
.catch((err) => console.log("Error",err))
const studentRecords = [
    {name:"zain",age:21,grade:"B"},
    {name:"Adeel",age:22,grade:"C"},
    {name:"Rizwan",age:23,grade:"B"}
];
StudentModel.insertMany(studentRecords)
.then(() => console.log("Students Saved"))
.catch((err) => console.log("Error",err));

StudentModel.updateMany({name:"Rafy"},{grade:"A"})
StudentModel.find()
.then((allStudents) => console.log("All students",allStudents))
.catch((err) => console.log("Error",err))

StudentModel.findByIdAndDelete()

;